import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import '../backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../auth/firebase_auth/auth_util.dart';

String? getLatAndLong(String? latandlong) {
  if (latandlong == null) {
    return null;
  }

  String? toReturn1 = latandlong.split("(lat:")[1];
  toReturn1 = toReturn1.split(',')[0];

  String? toReturn2 = latandlong.split(", lng:")[1];
  toReturn2 = toReturn2.substring(0, toReturn2.length - 1);
  return toReturn1 + ',' + toReturn2;
}

String? addAverage(double? tempString) {
  return "Average temp : " + tempString.toString();
}
