import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyAVKio_vQ1zVPrHa1UyQNBqQMOrGaGUmU4",
            authDomain: "myweatherapp-74123.firebaseapp.com",
            projectId: "myweatherapp-74123",
            storageBucket: "myweatherapp-74123.appspot.com",
            messagingSenderId: "1060774817563",
            appId: "1:1060774817563:web:82a335201d95098eefedbe",
            measurementId: "G-TL5XLKNJMJ"));
  } else {
    await Firebase.initializeApp();
  }
}
