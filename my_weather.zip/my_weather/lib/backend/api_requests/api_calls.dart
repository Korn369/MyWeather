import 'dart:convert';
import 'dart:typed_data';

import '../../flutter_flow/flutter_flow_util.dart';

import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class WeatherAPICall {
  static Future<ApiCallResponse> call({
    String? place = '',
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'WeatherAPI',
      apiUrl: 'https://weatherapi-com.p.rapidapi.com/current.json?q=${place}',
      callType: ApiCallType.GET,
      headers: {
        'X-RapidAPI-Key': 'ccdee4d428msh952c1699e36a8e4p123038jsn964687712fb0',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }

  static dynamic locationname(dynamic response) => getJsonField(
        response,
        r'''$.location.name''',
      );
  static dynamic locationregion(dynamic response) => getJsonField(
        response,
        r'''$.location.region''',
      );
  static dynamic locationcountry(dynamic response) => getJsonField(
        response,
        r'''$.location.country''',
      );
  static dynamic currenttempc(dynamic response) => getJsonField(
        response,
        r'''$.current.temp_c''',
      );
  static dynamic currentfeelslikec(dynamic response) => getJsonField(
        response,
        r'''$.current.feelslike_c''',
      );
  static dynamic currentconditionicon(dynamic response) => getJsonField(
        response,
        r'''$.current.condition.icon''',
      );
  static dynamic currentconditiontext(dynamic response) => getJsonField(
        response,
        r'''$.current.condition.text''',
      );
}

class ForecastCall {
  static Future<ApiCallResponse> call({
    String? place = '',
    int? daysnum = 4,
  }) {
    return ApiManager.instance.makeApiCall(
      callName: 'Forecast',
      apiUrl:
          'https://weatherapi-com.p.rapidapi.com/forecast.json?q=${place}&days=${daysnum}',
      callType: ApiCallType.GET,
      headers: {
        'X-RapidAPI-Key': 'ccdee4d428msh952c1699e36a8e4p123038jsn964687712fb0',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
    );
  }

  static dynamic avgtemp(dynamic response) => getJsonField(
        response,
        r'''$.forecast.forecastday[:].day.avgtemp_c''',
        true,
      );
  static dynamic date(dynamic response) => getJsonField(
        response,
        r'''$.forecast.forecastday[:].date''',
        true,
      );
  static dynamic condition(dynamic response) => getJsonField(
        response,
        r'''$.forecast.forecastday[:].day.condition.text''',
        true,
      );
  static dynamic conditionicon(dynamic response) => getJsonField(
        response,
        r'''$.forecast.forecastday[:].day.condition.icon''',
        true,
      );
  static dynamic locationname(dynamic response) => getJsonField(
        response,
        r'''$.location.name''',
      );
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list);
  } catch (_) {
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar) {
  jsonVar ??= {};
  try {
    return json.encode(jsonVar);
  } catch (_) {
    return '{}';
  }
}
